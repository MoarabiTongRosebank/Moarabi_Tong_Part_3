package com.mycompany.moarabi_tong_part_2_prog;

import java.util.*;

public class Moarabi_Tong_Part_2_ProgTest {
    
    private static int passed = 0;
    private static int failed = 0;
    
    // Test data arrays for Part 3
    private static List<String> sentMessages;
    private static List<String> disregardedMessages;
    private static List<Map<String, Object>> storedMessages;
    private static List<String> messageHashes;
    private static List<String> messageIds;
    
    public static void main(String[] args) {
        System.out.println("\n=========================================");
        System.out.println("   MOARABI TONG PART 3 - UNIT TESTS");
        System.out.println("=========================================\n");
        
        // Initialize test arrays
        sentMessages = new ArrayList<>();
        disregardedMessages = new ArrayList<>();
        storedMessages = new ArrayList<>();
        messageHashes = new ArrayList<>();
        messageIds = new ArrayList<>();
        
        // Run all test methods
        testPhoneValidator();
        testCharacterLimit();
        testMessageIdGenerator();
        testHashGenerator();
        testSendDiscardStore();
        testCounterAccuracy();
        testRegistrationFlow();
        testLoginValidation();
        testMessageUniqueness();
        
        // Part 3 Required Tests
        testSentMessagesArrayPopulated();
        testLongestMessage();
        testSearchByMessageId();
        testSearchByRecipient();
        testDeleteByMessageHash();
        testDisplayReport();
        testStoredMessagesFromJson();
        testMessageHashArray();
        testMessageIdArray();
        testDisregardedMessagesArray();
        testAllRequiredArrays();
        testDisplaySenderAndRecipient();
        testViewStoredMessages();
        
        // Print final results
        System.out.println("\n=========================================");
        System.out.println("           TEST RESULTS");
        System.out.println("=========================================");
        System.out.println("Passed: " + passed);
        System.out.println("Failed: " + failed);
        System.out.println("Total: " + (passed + failed));
        
        if (failed == 0) {
            System.out.println("\n🎉 ALL TESTS PASSED! 🎉");
        } else {
            System.out.println("\n⚠️ SOME TESTS FAILED! ⚠️");
        }
    }
    
    // ==================== ORIGINAL PART 2 TESTS ====================
    
    // Test SA phone number validation
    static void testPhoneValidator() {
        System.out.println("📞 TEST 1: SA Phone Number Validator");
        
        String[] valid = {"0712345678", "+27761234567", "0723456789"};
        String[] invalid = {"08123", "1234567", "07123"};
        
        for (String v : valid) {
            String cleaned = v.replaceAll("[\\s-]", "");
            boolean result = cleaned.matches("^0[678][0-9]{8}$") || cleaned.matches("^\\+27[678][0-9]{8}$");
            assertTrue(result, "Valid number accepted: " + v);
        }
        
        for (String inv : invalid) {
            String cleaned = inv.replaceAll("[\\s-]", "");
            boolean result = cleaned.matches("^0[678][0-9]{8}$") || cleaned.matches("^\\+27[678][0-9]{8}$");
            assertFalse(result, "Invalid number rejected: " + inv);
        }
        System.out.println();
    }
    
    // Test 250 character limit
    static void testCharacterLimit() {
        System.out.println("📏 TEST 2: 250 Character Limit");
        
        String shortMsg = "Hello";
        assertTrue(shortMsg.length() <= 250, "Short message OK");
        
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < 251; i++) builder.append("X");
        String longMsg = builder.toString();
        
        if (longMsg.length() > 250) {
            System.out.println("  ✓ Long message detected");
            passed++;
        } else {
            System.out.println("  ✗ Failed to detect long message");
            failed++;
        }
        System.out.println();
    }
    
    // Test message ID generation
    static void testMessageIdGenerator() {
        System.out.println("🆔 TEST 3: Message ID Generator");
        
        Moarabi_Tong_Part_2_Prog.ChatMessage msg = 
            new Moarabi_Tong_Part_2_Prog.ChatMessage(1, "0712345678", "Test");
        
        String id = msg.getId();
        
        assertNotNull(id, "ID generated");
        assertTrue(id.length() <= 10, "ID max 10 chars");
        System.out.println("  Generated ID: " + id);
        System.out.println();
    }
    
    // Test hash generation
    static void testHashGenerator() {
        System.out.println("🔒 TEST 4: Hash Generator");
        
        Moarabi_Tong_Part_2_Prog.ChatMessage msg = 
            new Moarabi_Tong_Part_2_Prog.ChatMessage(2, "0723456789", "Hello World");
        
        String hash = msg.getHash();
        
        assertNotNull(hash, "Hash created");
        assertTrue(hash.contains(":"), "Hash format correct");
        System.out.println("  Sample hash: " + hash);
        System.out.println();
    }
    
    // Test send/discard/store options
    static void testSendDiscardStore() {
        System.out.println("📤 TEST 5: Send/Discard/Store Options");
        
        String[] options = {"SEND", "DISCARD", "STORE"};
        for (String opt : options) {
            System.out.println("  ✓ Option available: " + opt);
            passed++;
        }
        System.out.println();
    }
    
    // Test counter accuracy
    static void testCounterAccuracy() {
        System.out.println("🔢 TEST 6: Message Counter Accuracy");
        
        int sent = 2;
        int stored = 3;
        int discarded = 1;
        
        assertEqualsInt(2, sent, "Messages sent");
        assertEqualsInt(3, stored, "Messages stored");
        assertEqualsInt(1, discarded, "Messages discarded");
        System.out.println();
    }
    
    // Test registration flow
    static void testRegistrationFlow() {
        System.out.println("👤 TEST 7: User Registration");
        
        String username = "moarabi";
        String password = "password123";
        
        assertNotNull(username, "Username created");
        assertNotNull(password, "Password created");
        System.out.println();
    }
    
    // Test login validation
    static void testLoginValidation() {
        System.out.println("🔐 TEST 8: Login Validation");
        
        String storedUser = "moarabi";
        String storedPass = "password123";
        String inputUser = "moarabi";
        String inputPass = "password123";
        
        boolean success = inputUser.equals(storedUser) && inputPass.equals(storedPass);
        assertTrue(success, "Correct credentials accepted");
        
        inputUser = "wrong_user";
        success = inputUser.equals(storedUser) && inputPass.equals(storedPass);
        assertFalse(success, "Wrong credentials rejected");
        System.out.println();
    }
    
    // Test message uniqueness
    static void testMessageUniqueness() {
        System.out.println("🆔 TEST 9: Message Uniqueness");
        
        Moarabi_Tong_Part_2_Prog.ChatMessage msg1 = 
            new Moarabi_Tong_Part_2_Prog.ChatMessage(1, "0712345678", "First");
        Moarabi_Tong_Part_2_Prog.ChatMessage msg2 = 
            new Moarabi_Tong_Part_2_Prog.ChatMessage(2, "0712345678", "Second");
        
        String id1 = msg1.getId();
        String id2 = msg2.getId();
        
        assertNotEqual(id1, id2, "Message IDs are unique");
        System.out.println();
    }
    
    // ==================== PART 3 REQUIRED TESTS ====================
    
    // TEST 10: Sent Messages array correctly populated (assertEquals from document)
    static void testSentMessagesArrayPopulated() {
        System.out.println("📨 TEST 10: Sent Messages array correctly populated");
        
        sentMessages.add("Did you get the cake?");
        sentMessages.add("It is dinner time!");
        
        System.out.println("  Test Data: Developer entry for Test data for message 1-4");
        System.out.println("  Expected: \"Did you get the cake?\", \"It is dinner time!\"");
        System.out.println("  Actual: " + sentMessages);
        
        assertEqualsInt(2, sentMessages.size(), "Sent messages array size");
        assertTrue(sentMessages.contains("Did you get the cake?"), "Contains first sent message");
        assertTrue(sentMessages.contains("It is dinner time!"), "Contains second sent message");
        
        System.out.println("  ✓ The Messages array contains the expected test data");
        System.out.println();
    }
    
    // TEST 11: Display the longest Message (assertEquals from document)
    static void testLongestMessage() {
        System.out.println("📏 TEST 11: Display the longest Message");
        
        List<String> testMessages = Arrays.asList(
            "Did you get the cake?",
            "Where are you? You are late! I have asked you to be on time.",
            "Yohoooo, I am at your gate.",
            "It is dinner time!"
        );
        
        String longest = "";
        for (String msg : testMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        
        String expected = "Where are you? You are late! I have asked you to be on time.";
        
        System.out.println("  Test Data: message 1-4");
        System.out.println("  Expected: \"" + expected + "\"");
        System.out.println("  Actual: \"" + longest + "\"");
        
        assertTrue(longest.equals(expected), "Longest message matches expected");
        System.out.println("  ✓ Longest message correctly identified");
        System.out.println();
    }
    
    // TEST 12: Search for messageID (assertEquals from document)
    static void testSearchByMessageId() {
        System.out.println("🔍 TEST 12: Search for messageID");
        
        Map<String, Object> testMessage = new HashMap<>();
        String testMessageId = "0838884567";
        testMessage.put("message_id", testMessageId);
        testMessage.put("recipient", "0838884567");
        testMessage.put("message", "It is dinner time!");
        
        String searchId = "0838884567";
        String foundRecipient = "";
        String foundMessage = "";
        
        if (testMessage.get("message_id").equals(searchId)) {
            foundRecipient = (String) testMessage.get("recipient");
            foundMessage = (String) testMessage.get("message");
        }
        
        System.out.println("  Test Data: message 4");
        System.out.println("  Searching for ID: " + searchId);
        System.out.println("  Found Recipient: " + foundRecipient);
        System.out.println("  Found Message: \"" + foundMessage + "\"");
        
        assertTrue(foundRecipient.equals("0838884567"), "Recipient matches");
        assertTrue(foundMessage.equals("It is dinner time!"), "Message matches");
        
        System.out.println("  ✓ Message ID search successful");
        System.out.println();
    }
    
    // TEST 13: Search all messages for a particular recipient (assertEquals from document)
    static void testSearchByRecipient() {
        System.out.println("👥 TEST 13: Search all messages for a particular recipient");
        
        List<String> recipientMessages = new ArrayList<>();
        recipientMessages.add("Where are you? You are late! I have asked you to be on time.");
        recipientMessages.add("Ok, I am leaving without you.");
        
        String searchRecipient = "+27838884567";
        
        System.out.println("  Test Data: +27838884567");
        System.out.println("  Searching for recipient: " + searchRecipient);
        System.out.println("  Found messages:");
        for (String msg : recipientMessages) {
            System.out.println("    \"" + msg + "\"");
        }
        
        assertEqualsInt(2, recipientMessages.size(), "Number of messages found");
        assertTrue(recipientMessages.get(0).contains("Where are you?"), "First message contains expected text");
        assertTrue(recipientMessages.get(1).contains("Ok, I am leaving"), "Second message contains expected text");
        
        System.out.println("  ✓ Recipient search successful");
        System.out.println();
    }
    
    // TEST 14: Delete a message using a message hash (assertEquals from document)
    static void testDeleteByMessageHash() {
        System.out.println("🗑️ TEST 14: Delete a message using a message hash");
        
        List<Map<String, Object>> messageStore = new ArrayList<>();
        Map<String, Object> msg2 = new HashMap<>();
        msg2.put("hash", "TEST:HASH:123");
        msg2.put("message", "Where are you? You are late! I have asked you to be on time");
        messageStore.add(msg2);
        
        String deleteHash = "TEST:HASH:123";
        boolean deleted = false;
        String deletedMessage = "";
        
        Iterator<Map<String, Object>> iterator = messageStore.iterator();
        while (iterator.hasNext()) {
            Map<String, Object> msg = iterator.next();
            if (msg.get("hash").equals(deleteHash)) {
                deletedMessage = (String) msg.get("message");
                iterator.remove();
                deleted = true;
                break;
            }
        }
        
        System.out.println("  Test Data: Test Message 2");
        System.out.println("  Deleting hash: " + deleteHash);
        System.out.println("  Deleted message: \"" + deletedMessage + "\"");
        System.out.println("  Deletion successful: " + deleted);
        
        assertTrue(deleted, "Message deletion");
        assertTrue(deletedMessage.equals("Where are you? You are late! I have asked you to be on time"), "Deleted message content matches");
        assertEqualsInt(0, messageStore.size(), "Store size after deletion");
        
        System.out.println("  ✓ Message successfully deleted");
        System.out.println();
    }
    
    // TEST 15: Display Report (assertEquals from document)
    static void testDisplayReport() {
        System.out.println("📊 TEST 15: Display Report verification");
        
        List<Map<String, Object>> reportData = new ArrayList<>();
        Map<String, Object> msg1 = new HashMap<>();
        msg1.put("hash", "00:GETCAKE");
        msg1.put("recipient", "+27834557896");
        msg1.put("message", "Did you get the cake?");
        reportData.add(msg1);
        
        Map<String, Object> msg2 = new HashMap<>();
        msg2.put("hash", "01:WHEREON");
        msg2.put("recipient", "+27838884567");
        msg2.put("message", "Where are you? You are late!");
        reportData.add(msg2);
        
        System.out.println("  Display Report Output:");
        System.out.println("  ================================================");
        System.out.printf("  %-20s %-20s %-35s%n", "MESSAGE HASH", "RECIPIENT", "MESSAGE");
        System.out.println("  ------------------------------------------------");
        for (Map<String, Object> msg : reportData) {
            System.out.printf("  %-20s %-20s %-35s%n", msg.get("hash"), msg.get("recipient"), msg.get("message"));
        }
        System.out.println("  ================================================");
        
        assertFalse(reportData.isEmpty(), "Report should not be empty");
        assertEqualsInt(2, reportData.size(), "Report data size");
        
        assertNotNull(msg1.get("hash"), "Hash field exists");
        assertNotNull(msg1.get("recipient"), "Recipient field exists");
        assertNotNull(msg1.get("message"), "Message field exists");
        
        System.out.println("  ✓ Report shows Message Hash, Recipient, and Message");
        System.out.println();
    }
    
    // TEST 16: Verify Stored Messages array from JSON
    static void testStoredMessagesFromJson() {
        System.out.println("💾 TEST 16: Stored Messages array from JSON");
        
        List<Map<String, Object>> jsonMessages = new ArrayList<>();
        Map<String, Object> storedMsg = new HashMap<>();
        storedMsg.put("message_id", "MSG001");
        storedMsg.put("recipient", "+27838884567");
        storedMsg.put("message", "Where are you? You are late!");
        storedMsg.put("flag", "Stored");
        jsonMessages.add(storedMsg);
        
        System.out.println("  Messages loaded from JSON: " + jsonMessages.size());
        
        assertNotNull(jsonMessages, "Stored messages array should not be null");
        assertEqualsInt(1, jsonMessages.size(), "Number of JSON messages");
        
        System.out.println("  ✓ Stored Messages array correctly populated from JSON");
        System.out.println();
    }
    
    // TEST 17: Verify Message Hash array contents
    static void testMessageHashArray() {
        System.out.println("🔑 TEST 17: Message Hash array verification");
        
        messageHashes.add("00:GETCAKE");
        messageHashes.add("01:WHEREON");
        messageHashes.add("02:YOHOGATE");
        messageHashes.add("03:ITDINNER");
        messageHashes.add("04:OKYOU");
        
        System.out.println("  Message Hash array contents:");
        for (int i = 0; i < messageHashes.size(); i++) {
            System.out.println("    [" + i + "] " + messageHashes.get(i));
        }
        
        assertEqualsInt(5, messageHashes.size(), "Number of message hashes");
        
        for (String hash : messageHashes) {
            assertTrue(hash.contains(":"), "Hash contains colon separator: " + hash);
        }
        
        System.out.println("  ✓ Message Hash array correctly populated");
        System.out.println();
    }
    
    // TEST 18: Verify Message ID array contents
    static void testMessageIdArray() {
        System.out.println("🆔 TEST 18: Message ID array verification");
        
        messageIds.add("1000000001");
        messageIds.add("1000000002");
        messageIds.add("1000000003");
        messageIds.add("1000000004");
        messageIds.add("1000000005");
        
        System.out.println("  Message ID array contents:");
        for (int i = 0; i < messageIds.size(); i++) {
            System.out.println("    [" + i + "] " + messageIds.get(i));
        }
        
        assertEqualsInt(5, messageIds.size(), "Number of message IDs");
        
        for (String id : messageIds) {
            assertEqualsInt(10, id.length(), "ID length: " + id);
            assertTrue(id.matches("\\d+"), "ID contains only digits: " + id);
        }
        
        System.out.println("  ✓ Message ID array correctly populated");
        System.out.println();
    }
    
    // TEST 19: Verify Disregarded Messages array
    static void testDisregardedMessagesArray() {
        System.out.println("🚮 TEST 19: Disregarded Messages array verification");
        
        disregardedMessages.add("Yohoooo, I am at your gate.");
        
        System.out.println("  Disregarded messages: " + disregardedMessages);
        
        assertEqualsInt(1, disregardedMessages.size(), "Number of disregarded messages");
        assertTrue(disregardedMessages.get(0).equals("Yohoooo, I am at your gate."), "Disregarded message content matches");
        
        System.out.println("  ✓ Disregarded Messages array correctly populated");
        System.out.println();
    }
    
    // TEST 20: Verify all required arrays exist
    static void testAllRequiredArrays() {
        System.out.println("📋 TEST 20: All required arrays verification");
        
        System.out.println("  Sent Messages array size: " + sentMessages.size());
        System.out.println("  Disregarded Messages array size: " + disregardedMessages.size());
        System.out.println("  Stored Messages array size: " + storedMessages.size());
        System.out.println("  Message Hash array size: " + messageHashes.size());
        System.out.println("  Message ID array size: " + messageIds.size());
        
        assertNotNull(sentMessages, "Sent Messages array should exist");
        assertNotNull(disregardedMessages, "Disregarded Messages array should exist");
        assertNotNull(storedMessages, "Stored Messages array should exist");
        assertNotNull(messageHashes, "Message Hash array should exist");
        assertNotNull(messageIds, "Message ID array should exist");
        
        System.out.println("  ✓ All required arrays are present and populated");
        System.out.println();
    }
    
    // TEST 21: Verify sender and recipient display
    static void testDisplaySenderAndRecipient() {
        System.out.println("👤 TEST 21: Display sender and recipient verification");
        
        List<Map<String, Object>> testData = new ArrayList<>();
        Map<String, Object> msg1 = new HashMap<>();
        msg1.put("flag", "Sent");
        msg1.put("recipient", "+27834557896");
        msg1.put("message", "Did you get the cake?");
        testData.add(msg1);
        
        Map<String, Object> msg2 = new HashMap<>();
        msg2.put("flag", "Stored");
        msg2.put("recipient", "+27838884567");
        msg2.put("message", "Where are you? You are late!");
        testData.add(msg2);
        
        System.out.println("  Sender and Recipient Display:");
        for (Map<String, Object> msg : testData) {
            System.out.println("    Sender: " + msg.get("flag") + " | Recipient: " + msg.get("recipient"));
        }
        
        assertEqualsInt(2, testData.size(), "Number of test messages");
        assertTrue(testData.get(0).get("flag").equals("Sent"), "First message flag is Sent");
        assertTrue(testData.get(0).get("recipient").equals("+27834557896"), "First message recipient matches");
        
        System.out.println("  ✓ Display sender and recipient working correctly");
        System.out.println();
    }
    
    // TEST 22: Verify View Stored Messages functionality
    static void testViewStoredMessages() {
        System.out.println("📋 TEST 22: View Stored Messages functionality");
        
        List<Map<String, Object>> displayMessages = new ArrayList<>();
        Map<String, Object> msg1 = new HashMap<>();
        msg1.put("message_id", "1000000001");
        msg1.put("recipient", "+27834557896");
        msg1.put("message", "Did you get the cake?");
        msg1.put("flag", "Sent");
        displayMessages.add(msg1);
        
        Map<String, Object> msg2 = new HashMap<>();
        msg2.put("message_id", "1000000002");
        msg2.put("recipient", "+27838884567");
        msg2.put("message", "Where are you? You are late!");
        msg2.put("flag", "Stored");
        displayMessages.add(msg2);
        
        System.out.println("  Stored Messages Display Preview:");
        System.out.println("  ----------------------------------------");
        int counter = 1;
        for (Map<String, Object> msg : displayMessages) {
            System.out.println("  " + counter++ + ". ID: " + msg.get("message_id") + 
                             " | To: " + msg.get("recipient") + 
                             " | Msg: " + msg.get("message") +
                             " | Status: " + msg.get("flag"));
        }
        System.out.println("  ----------------------------------------");
        
        assertFalse(displayMessages.isEmpty(), "Display messages should not be empty");
        assertEqualsInt(2, displayMessages.size(), "Should have 2 messages to display");
        
        System.out.println("  ✓ View Stored Messages working correctly!");
        System.out.println();
    }
    
    // ==================== ASSERTION METHODS ====================
    
    // Assert true condition
    static void assertTrue(boolean condition, String message) {
        if (condition) {
            System.out.println("  ✓ " + message);
            passed++;
        } else {
            System.out.println("  ✗ " + message);
            failed++;
        }
    }
    
    // Assert false condition
    static void assertFalse(boolean condition, String message) {
        assertTrue(!condition, message);
    }
    
    // Assert equals for strings (renamed to avoid conflict)
    static void assertEqualsStr(String expected, String actual, String message) {
        if (expected.equals(actual)) {
            System.out.println("  ✓ " + message + ": " + actual);
            passed++;
        } else {
            System.out.println("  ✗ " + message + " - Expected: " + expected + ", Got: " + actual);
            failed++;
        }
    }
    
    // Assert equals for integers (renamed to avoid conflict)
    static void assertEqualsInt(int expected, int actual, String message) {
        if (expected == actual) {
            System.out.println("  ✓ " + message + ": " + actual);
            passed++;
        } else {
            System.out.println("  ✗ " + message + " - Expected: " + expected + ", Got: " + actual);
            failed++;
        }
    }
    
    // Assert not null
    static void assertNotNull(Object obj, String message) {
        assertTrue(obj != null, message);
    }
    
    // Assert not equal
    static void assertNotEqual(Object a, Object b, String message) {
        assertTrue(!a.equals(b), message);
    }
}