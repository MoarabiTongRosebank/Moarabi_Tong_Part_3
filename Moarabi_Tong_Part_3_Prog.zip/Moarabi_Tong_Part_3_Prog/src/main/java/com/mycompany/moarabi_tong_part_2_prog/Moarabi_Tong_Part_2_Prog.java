package com.mycompany.moarabi_tong_part_2_prog;

import javax.swing.*;
import java.io.*;
import java.util.*;

public class Moarabi_Tong_Part_2_Prog {
    
    // Part 3 Required Arrays (no hard-coding)
    static List<String> sentMessagesList = new ArrayList<>();        // Contains all messages sent
    static List<String> disregardedMessagesList = new ArrayList<>(); // Contains all disregarded messages
    static List<Map<String, Object>> storedMessagesList = new ArrayList<>(); // Contains stored messages from JSON
    static List<String> messageHashesList = new ArrayList<>();       // Contains all message hashes
    static List<String> messageIdsList = new ArrayList<>();          // Contains all message IDs
    
    // Original storage for messages
    static List<String> msgIds = new ArrayList<>();
    static List<String> msgHashes = new ArrayList<>();
    static List<String> msgRecipients = new ArrayList<>();
    static List<String> msgContents = new ArrayList<>();
    static List<String> msgStates = new ArrayList<>();
    
    // User account
    static String savedUsername = "";
    static String savedPassword = "";
    static boolean userExists = false;
    
    // Message counters
    static int sentCounter = 0;
    static int storedCounter = 0;
    static int discardedCounter = 0;
    
    static final String JSON_STORAGE = "moarabi_messages.json";
    
    public static void main(String[] args) {
        showSplashScreen();
        
        boolean loggedIn = false;
        
        while (!loggedIn) {
            String menuChoice = showMainMenu();
            
            if (menuChoice == null) {
                showMessage("Goodbye!", "Exit");
                System.exit(0);
            }
            
            switch (menuChoice) {
                case "1":
                    registerNewUser();
                    break;
                case "2":
                    if (userExists) {
                        loggedIn = performLogin();
                    } else {
                        showMessage("No account found! Please register first.", "Error");
                    }
                    break;
                case "3":
                    int confirm = JOptionPane.showConfirmDialog(null, 
                        "Are you sure you want to exit?", 
                        "Confirm Exit", 
                        JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        showMessage("Thank you for using Quick Chat!", "Goodbye");
                        System.exit(0);
                    }
                    break;
                default:
                    showMessage("Invalid option! Please choose 1, 2, or 3.", "Error");
            }
        }
        
        // Load test data from document
        loadTestData();
        
        launchChatSystem();
    }
    
    // Load test data as specified in the document
    static void loadTestData() {
        System.out.println("\n=== LOADING TEST DATA ===");
        
        // Test Data Message 1 - Sent
        addTestMessage("+27834557896", "Did you get the cake?", "Sent");
        
        // Test Data Message 2 - Stored
        addTestMessage("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored");
        
        // Test Data Message 3 - Disregard
        addTestMessage("+27834484567", "Yohoooo, I am at your gate.", "Disregard");
        
        // Test Data Message 4 - Sent (Developer entry)
        addTestMessage("0838884567", "It is dinner time!", "Sent");
        
        // Test Data Message 5 - Stored
        addTestMessage("+27838884567", "Ok, I am leaving without you.", "Stored");
        
        System.out.println("Test data loaded successfully!");
        System.out.println("Sent Messages: " + sentMessagesList.size());
        System.out.println("Stored Messages: " + storedMessagesList.size());
        System.out.println("Disregarded Messages: " + disregardedMessagesList.size());
    }
    
    static void addTestMessage(String recipient, String message, String flag) {
        String msgId = generateSimpleId();
        String msgHash = generateSimpleHash(message, msgId);
        
        // Populate required arrays
        messageIdsList.add(msgId);
        messageHashesList.add(msgHash);
        
        // Create stored message object
        Map<String, Object> storedMsg = new HashMap<>();
        storedMsg.put("message_id", msgId);
        storedMsg.put("hash", msgHash);
        storedMsg.put("recipient", recipient);
        storedMsg.put("message", message);
        storedMsg.put("flag", flag);
        
        if (flag.equalsIgnoreCase("Sent")) {
            sentMessagesList.add(message);
            storedMessagesList.add(storedMsg);
        } else if (flag.equalsIgnoreCase("Disregard")) {
            disregardedMessagesList.add(message);
        } else if (flag.equalsIgnoreCase("Stored")) {
            storedMessagesList.add(storedMsg);
        }
    }
    
    static String generateSimpleId() {
        Random r = new Random();
        long num = 1000000000L + (long)(r.nextDouble() * 9000000000L);
        String result = String.valueOf(num);
        if (result.length() > 10) {
            result = result.substring(0, 10);
        }
        return result;
    }
    
    static String generateSimpleHash(String message, String messageId) {
        String[] words = message.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0].replaceAll("[^A-Za-z]", "").toUpperCase() : "";
        String lastWord = words.length > 1 ? words[words.length - 1].replaceAll("[^A-Za-z]", "").toUpperCase() : firstWord;
        String idPrefix = messageId.substring(0, 2);
        return idPrefix + ":" + firstWord + lastWord;
    }
    
    // Display welcome screen
    static void showSplashScreen() {
        String welcomeMsg = "WELCOME TO QUICK CHAT SYSTEM\nMoarabi Tong - Part 3";
        JOptionPane.showMessageDialog(null, welcomeMsg, "Quick Chat v3.0", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Show main menu options
    static String showMainMenu() {
        String menu = "QUICK CHAT MAIN MENU\n\n1. Create New Account\n2. Login to Account\n3. Exit Application\n\nEnter your choice:";
        return JOptionPane.showInputDialog(null, menu, "Main Menu", JOptionPane.QUESTION_MESSAGE);
    }
    
    // Register new user account
    static void registerNewUser() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        JTextField usernameField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        
        panel.add(new JLabel("Choose Username:"));
        panel.add(usernameField);
        panel.add(Box.createVerticalStrut(10));
        panel.add(new JLabel("Choose Password:"));
        panel.add(passwordField);
        
        int result = JOptionPane.showConfirmDialog(null, panel, "Account Registration", 
                         JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
            savedUsername = usernameField.getText().trim();
            savedPassword = new String(passwordField.getPassword()).trim();
            userExists = true;
            showMessage("Account created successfully!\n\nUsername: " + savedUsername, "Success");
        }
    }
    
    // Verify user login
    static boolean performLogin() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        JTextField usernameField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        
        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(Box.createVerticalStrut(10));
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        
        int result = JOptionPane.showConfirmDialog(null, panel, "Login", 
                         JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
            String enteredUser = usernameField.getText().trim();
            String enteredPass = new String(passwordField.getPassword()).trim();
            
            if (enteredUser.equals(savedUsername) && enteredPass.equals(savedPassword)) {
                showMessage("Login successful!\n\nWelcome back, " + savedUsername + "!", "Success");
                return true;
            } else {
                showMessage("Login failed!\nInvalid username or password.", "Error");
                return false;
            }
        }
        return false;
    }
    
    // Main chat system
    static void launchChatSystem() {
        String msgCountInput = JOptionPane.showInputDialog(null, 
            "HOW MANY MESSAGES?\n\nEnter the number of messages you would like to create:", 
            "Message Setup", JOptionPane.QUESTION_MESSAGE);
        
        if (msgCountInput == null) return;
        
        int totalMessages;
        try {
            totalMessages = Integer.parseInt(msgCountInput);
            if (totalMessages <= 0) {
                showMessage("Please enter a positive number!", "Error");
                return;
            }
        } catch (NumberFormatException e) {
            showMessage("Invalid number format!", "Error");
            return;
        }
        
        boolean appRunning = true;
        
        while (appRunning) {
            String option = showChatMenu();
            
            if (option == null) {
                appRunning = false;
                continue;
            }
            
            switch (option) {
                case "1":
                    processAllMessages(totalMessages);
                    showFinalReport();
                    int continueChoice = JOptionPane.showConfirmDialog(null, 
                        "Would you like to continue using Quick Chat?", 
                        "Continue?", JOptionPane.YES_NO_OPTION);
                    if (continueChoice != JOptionPane.YES_OPTION) {
                        appRunning = false;
                    }
                    break;
                case "2":
                    viewStoredMessages();
                    break;
                case "3":
                    storedMessagesMenu();
                    break;
                case "4":
                    int exitConfirm = JOptionPane.showConfirmDialog(null, 
                        "Are you sure you want to exit?", 
                        "Exit Quick Chat", JOptionPane.YES_NO_OPTION);
                    if (exitConfirm == JOptionPane.YES_OPTION) {
                        appRunning = false;
                        showMessage("Goodbye! Thanks for using Quick Chat!", "Farewell");
                    }
                    break;
                default:
                    showMessage("Invalid option! Please choose 1, 2, 3, or 4.", "Error");
            }
        }
    }
    
    // Show chat menu
    static String showChatMenu() {
        String menu = "QUICK CHAT MENU\n\n1. Compose & Send Messages\n2. View Stored Messages\n3. Stored Messages Menu (Advanced)\n4. Exit Application\n\nEnter your choice:";
        return JOptionPane.showInputDialog(null, menu, "Quick Chat Dashboard", JOptionPane.QUESTION_MESSAGE);
    }
    
    // VIEW STORED MESSAGES - Simple view
    static void viewStoredMessages() {
        if (storedMessagesList.isEmpty()) {
            showMessage("No messages found in storage.", "Stored Messages");
            return;
        }
        
        StringBuilder display = new StringBuilder();
        display.append("═══════════════════════════════════════════════════════════\n");
        display.append("                 STORED MESSAGES LIST                      \n");
        display.append("═══════════════════════════════════════════════════════════\n\n");
        display.append(String.format("%-5s %-15s %-15s %-35s %-10s\n", "No.", "MESSAGE ID", "RECIPIENT", "MESSAGE", "STATUS"));
        display.append("------------------------------------------------------------------------\n");
        
        int counter = 1;
        for (Map<String, Object> msg : storedMessagesList) {
            String msgId = (String) msg.get("message_id");
            String recipient = (String) msg.get("recipient");
            String message = (String) msg.get("message");
            String flag = (String) msg.get("flag");
            
            String shortMessage = message.length() > 32 ? message.substring(0, 29) + "..." : message;
            
            display.append(String.format("%-5d %-15s %-15s %-35s %-10s\n", counter++, msgId, recipient, shortMessage, flag));
        }
        
        display.append("------------------------------------------------------------------------\n");
        display.append("Total Messages: ").append(storedMessagesList.size()).append("\n");
        
        showMessage(display.toString(), "Stored Messages");
        
        // Option to view full details
        String viewDetail = JOptionPane.showInputDialog(null, "Enter message number to view full details (1-" + storedMessagesList.size() + "), or cancel to skip:");
        if (viewDetail != null) {
            try {
                int msgNum = Integer.parseInt(viewDetail);
                if (msgNum >= 1 && msgNum <= storedMessagesList.size()) {
                    Map<String, Object> selectedMsg = storedMessagesList.get(msgNum - 1);
                    String details = "═══════════════════════════════════════════\n";
                    details += "           FULL MESSAGE DETAILS                 \n";
                    details += "═══════════════════════════════════════════\n";
                    details += "Message ID:   " + selectedMsg.get("message_id") + "\n";
                    details += "Hash:         " + selectedMsg.get("hash") + "\n";
                    details += "Recipient:    " + selectedMsg.get("recipient") + "\n";
                    details += "Message:      " + selectedMsg.get("message") + "\n";
                    details += "Status:       " + selectedMsg.get("flag") + "\n";
                    showMessage(details, "Message Details");
                } else {
                    showMessage("Invalid message number!", "Error");
                }
            } catch (NumberFormatException e) {
                showMessage("Invalid input!", "Error");
            }
        }
    }
    
    // STORED MESSAGES MENU - Advanced options (FOURTH MAIN MENU OPTION)
    static void storedMessagesMenu() {
        boolean backToMain = false;
        while (!backToMain) {
            String[] options = {
                "Display sender and recipient of all messages",
                "Display the longest stored message",
                "Search for a message by ID",
                "Search for messages by recipient",
                "Delete a message using message hash",
                "Display full report",
                "Return to Main Menu"
            };
            
            int choice = JOptionPane.showOptionDialog(null,
                "STORED MESSAGES - ADVANCED MENU\n\nSelect an option:",
                "Stored Messages Menu",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);
            
            switch (choice) {
                case 0:
                    displaySenderAndRecipient();
                    break;
                case 1:
                    displayLongestStoredMessage();
                    break;
                case 2:
                    searchByMessageId();
                    break;
                case 3:
                    searchByRecipient();
                    break;
                case 4:
                    deleteByMessageHash();
                    break;
                case 5:
                    displayFullReport();
                    break;
                case 6:
                    backToMain = true;
                    break;
                default:
                    backToMain = true;
            }
        }
    }
    
    // 2a: Display sender and recipient of all stored messages
    static void displaySenderAndRecipient() {
        if (storedMessagesList.isEmpty()) {
            showMessage("No stored messages found.", "Information");
            return;
        }
        
        StringBuilder report = new StringBuilder();
        report.append("═══════════════════════════════════════════════════════════\n");
        report.append("          SENDER AND RECIPIENT OF STORED MESSAGES         \n");
        report.append("═══════════════════════════════════════════════════════════\n\n");
        report.append(String.format("%-20s %-20s %-45s\n", "SENDER (FLAG)", "RECIPIENT", "MESSAGE"));
        report.append("------------------------------------------------------------------------\n");
        
        for (Map<String, Object> msg : storedMessagesList) {
            String sender = (String) msg.get("flag");
            String recipient = (String) msg.get("recipient");
            String message = (String) msg.get("message");
            
            if (message.length() > 42) {
                message = message.substring(0, 39) + "...";
            }
            
            report.append(String.format("%-20s %-20s %-45s\n", sender, recipient, message));
        }
        
        showMessage(report.toString(), "Sender and Recipient");
    }
    
    // 2b: Display the longest stored message
    static void displayLongestStoredMessage() {
        if (storedMessagesList.isEmpty()) {
            showMessage("No stored messages found.", "Information");
            return;
        }
        
        Map<String, Object> longestMsg = null;
        int maxLength = 0;
        
        for (Map<String, Object> msg : storedMessagesList) {
            String message = (String) msg.get("message");
            if (message.length() > maxLength) {
                maxLength = message.length();
                longestMsg = msg;
            }
        }
        
        if (longestMsg != null) {
            String result = "═══════════════════════════════════════════\n";
            result += "           LONGEST STORED MESSAGE              \n";
            result += "═══════════════════════════════════════════\n";
            result += "Recipient: " + longestMsg.get("recipient") + "\n";
            result += "Message:   \"" + longestMsg.get("message") + "\"\n";
            result += "Length:    " + maxLength + " characters\n";
            showMessage(result, "Longest Message");
        }
    }
    
    // 2c: Search for a message ID and display recipient and message
    static void searchByMessageId() {
        String searchId = JOptionPane.showInputDialog(null, "Enter Message ID to search:", "Search by ID", JOptionPane.QUESTION_MESSAGE);
        if (searchId == null) return;
        
        boolean found = false;
        for (Map<String, Object> msg : storedMessagesList) {
            if (msg.get("message_id").equals(searchId)) {
                String result = "✅ Message Found!\n\n";
                result += "Recipient: " + msg.get("recipient") + "\n";
                result += "Message:   \"" + msg.get("message") + "\"";
                showMessage(result, "Search Result");
                found = true;
                break;
            }
        }
        
        if (!found) {
            showMessage("❌ No message found with ID: " + searchId, "Not Found");
        }
    }
    
    // 2d: Search for all messages stored for a particular recipient
    static void searchByRecipient() {
        String searchRecipient = JOptionPane.showInputDialog(null, "Enter recipient number to search:", "Search by Recipient", JOptionPane.QUESTION_MESSAGE);
        if (searchRecipient == null) return;
        
        boolean found = false;
        StringBuilder results = new StringBuilder();
        results.append("Messages for recipient: ").append(searchRecipient).append("\n");
        results.append("----------------------------------------\n");
        
        for (Map<String, Object> msg : storedMessagesList) {
            if (msg.get("recipient").equals(searchRecipient)) {
                results.append("• \"").append(msg.get("message")).append("\"\n");
                found = true;
            }
        }
        
        if (found) {
            showMessage(results.toString(), "Search Results");
        } else {
            showMessage("❌ No messages found for recipient: " + searchRecipient, "Not Found");
        }
    }
    
    // 2e: Delete a message using the message hash
    static void deleteByMessageHash() {
        String searchHash = JOptionPane.showInputDialog(null, "Enter Message Hash to delete:", "Delete by Hash", JOptionPane.QUESTION_MESSAGE);
        if (searchHash == null) return;
        
        boolean found = false;
        Iterator<Map<String, Object>> iterator = storedMessagesList.iterator();
        String deletedMessage = "";
        
        while (iterator.hasNext()) {
            Map<String, Object> msg = iterator.next();
            if (msg.get("hash").equals(searchHash)) {
                deletedMessage = (String) msg.get("message");
                iterator.remove();
                found = true;
                break;
            }
        }
        
        if (found) {
            showMessage("✅ Message successfully deleted!\n\nMessage: \"" + deletedMessage + "\"", "Deleted");
        } else {
            showMessage("❌ No message found with hash: " + searchHash, "Not Found");
        }
    }
    
    // 2f: Display report with full details of all stored messages
    static void displayFullReport() {
        if (storedMessagesList.isEmpty()) {
            showMessage("NO STORED MESSAGES AVAILABLE", "Report");
            return;
        }
        
        StringBuilder report = new StringBuilder();
        report.append("═══════════════════════════════════════════════════════════════════════════════════════════\n");
        report.append("                         COMPLETE STORED MESSAGES REPORT                                \n");
        report.append("═══════════════════════════════════════════════════════════════════════════════════════════\n\n");
        report.append(String.format("%-20s %-20s %-15s %-45s\n", "MESSAGE HASH", "RECIPIENT", "MESSAGE ID", "MESSAGE"));
        report.append("----------------------------------------------------------------------------------------\n");
        
        for (Map<String, Object> msg : storedMessagesList) {
            String hash = (String) msg.get("hash");
            String recipient = (String) msg.get("recipient");
            String msgId = (String) msg.get("message_id");
            String message = (String) msg.get("message");
            
            if (message.length() > 42) {
                message = message.substring(0, 39) + "...";
            }
            
            report.append(String.format("%-20s %-20s %-15s %-45s\n", hash, recipient, msgId, message));
        }
        
        report.append("\n═══════════════════════════════════════════════════════════════════════════════════════════\n");
        report.append("Total Stored Messages:   ").append(storedMessagesList.size()).append("\n");
        report.append("Total Sent Messages:     ").append(sentMessagesList.size()).append("\n");
        report.append("Total Disregarded:       ").append(disregardedMessagesList.size()).append("\n");
        
        showMessage(report.toString(), "Complete Report");
    }
    
    // Process all messages
    static void processAllMessages(int total) {
        for (int i = 0; i < total; i++) {
            JOptionPane.showMessageDialog(null, 
                "MESSAGE " + (i + 1) + " of " + total + "\n\nLet's compose your message!", 
                "New Message", JOptionPane.INFORMATION_MESSAGE);
            
            String phoneNumber = getValidPhoneNumber();
            if (phoneNumber == null) return;
            
            String messageText = getValidMessageText();
            if (messageText == null) return;
            
            ChatMessage msg = new ChatMessage(i + 1, phoneNumber, messageText);
            
            String preview = "MESSAGE PREVIEW\n\nMessage ID: " + msg.getId() + 
                           "\nHash: " + msg.getHash() + 
                           "\nTo: " + msg.getRecipient() + 
                           "\nMessage: " + msg.getContent();
            
            JOptionPane.showMessageDialog(null, preview, "Message Preview", JOptionPane.INFORMATION_MESSAGE);
            
            String action = getMessageAction();
            if (action == null) return;
            
            if (action.equals("SEND")) {
                // Add to arrays
                sentMessagesList.add(msg.getContent());
                messageIdsList.add(msg.getId());
                messageHashesList.add(msg.getHash());
                
                Map<String, Object> storedMsg = new HashMap<>();
                storedMsg.put("message_id", msg.getId());
                storedMsg.put("hash", msg.getHash());
                storedMsg.put("recipient", msg.getRecipient());
                storedMsg.put("message", msg.getContent());
                storedMsg.put("flag", "Sent");
                storedMessagesList.add(storedMsg);
                
                // Original storage
                msgIds.add(msg.getId());
                msgHashes.add(msg.getHash());
                msgRecipients.add(msg.getRecipient());
                msgContents.add(msg.getContent());
                msgStates.add("SENT");
                sentCounter++;
                showMessage("MESSAGE SENT SUCCESSFULLY!", "Message Sent");
                
            } else if (action.equals("STORE")) {
                messageIdsList.add(msg.getId());
                messageHashesList.add(msg.getHash());
                
                Map<String, Object> storedMsg = new HashMap<>();
                storedMsg.put("message_id", msg.getId());
                storedMsg.put("hash", msg.getHash());
                storedMsg.put("recipient", msg.getRecipient());
                storedMsg.put("message", msg.getContent());
                storedMsg.put("flag", "Stored");
                storedMessagesList.add(storedMsg);
                
                // Original storage
                msgIds.add(msg.getId());
                msgHashes.add(msg.getHash());
                msgRecipients.add(msg.getRecipient());
                msgContents.add(msg.getContent());
                msgStates.add("STORED");
                storedCounter++;
                msg.saveToFile();
                showMessage("MESSAGE SAVED TO STORAGE!", "Message Stored");
                
            } else if (action.equals("DISCARD")) {
                disregardedMessagesList.add(messageText);
                discardedCounter++;
                showMessage("MESSAGE DISCARDED!", "Message Discarded");
            }
        }
    }
    
    // Get and validate South African phone number
    static String getValidPhoneNumber() {
        while (true) {
            String phone = JOptionPane.showInputDialog(null, 
                "RECIPIENT PHONE NUMBER\n\nEnter South African number:\nFormat: 0712345678 or +27712345678", 
                "Phone Number", JOptionPane.QUESTION_MESSAGE);
            
            if (phone == null) return null;
            
            String cleaned = phone.replaceAll("[\\s-]", "");
            
            if (cleaned.matches("^0[678][0-9]{8}$") || cleaned.matches("^\\+27[678][0-9]{8}$")) {
                return phone;
            } else {
                JOptionPane.showMessageDialog(null, 
                    "Invalid South African number!\n\nPlease use format: 0712345678 or +27712345678", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    // Get and validate message text (max 250 characters)
    static String getValidMessageText() {
        while (true) {
            String message = JOptionPane.showInputDialog(null, 
                "COMPOSE YOUR MESSAGE\n\nEnter your message below:\n(Maximum 250 characters)", 
                "New Message", JOptionPane.QUESTION_MESSAGE);
            
            if (message == null) return null;
            
            if (message.length() <= 250) {
                return message;
            } else {
                int excess = message.length() - 250;
                JOptionPane.showMessageDialog(null, 
                    "Message too long!\n\nYour message exceeds the limit by " + excess + " characters.\nPlease shorten your message to 250 characters or less.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    // Get user action for message (send, discard, store)
    static String getMessageAction() {
        String[] options = {"SEND NOW", "DISCARD", "STORE FOR LATER"};
        
        int choice = JOptionPane.showOptionDialog(null,
            "WHAT WOULD YOU LIKE TO DO?\n\nChoose an action for this message:",
            "Message Options",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]);
        
        if (choice == 0) return "SEND";
        if (choice == 1) return "DISCARD";
        if (choice == 2) return "STORE";
        return null;
    }
    
    // Display final report
    static void showFinalReport() {
        String report = "FINAL MESSAGE REPORT\n\n" +
                       "Messages Sent: " + sentCounter + "\n" +
                       "Messages Stored: " + storedCounter + "\n" +
                       "Messages Discarded: " + discardedCounter + "\n" +
                       "Total Processed: " + (sentCounter + storedCounter + discardedCounter);
        
        JOptionPane.showMessageDialog(null, report, "Message Summary", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Helper method to show messages
    static void showMessage(String msg, String title) {
        JOptionPane.showMessageDialog(null, msg, title, JOptionPane.INFORMATION_MESSAGE);
    }
    
    // ========== INNER MESSAGE CLASS ==========
    
    static class ChatMessage {
        private String uniqueId;
        private int sequence;
        private String destination;
        private String textContent;
        private String securityHash;
        
        // Constructor
        public ChatMessage(int seq, String phone, String text) {
            this.sequence = seq;
            this.destination = phone;
            this.textContent = text;
            this.uniqueId = generateId();
            this.securityHash = computeHash();
        }
        
        // Generate unique message ID (max 10 chars)
        private String generateId() {
            Random rand = new Random();
            long idNum = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
            String idStr = String.valueOf(idNum);
            if (idStr.length() > 10) {
                idStr = idStr.substring(0, 10);
            }
            return idStr;
        }
        
        // Compute hash for message
        private String computeHash() {
            String prefix = this.uniqueId.substring(0, 2);
            String[] words = this.textContent.trim().split("\\W+");
            String first = words.length > 0 ? words[0].toUpperCase() : "";
            String last = words.length > 1 ? words[words.length-1].toUpperCase() : first;
            
            first = first.replaceAll("[^A-Z]", "");
            last = last.replaceAll("[^A-Z]", "");
            
            if (first.length() > 5) first = first.substring(0, 5);
            if (last.length() > 5) last = last.substring(0, 5);
            
            return prefix + ":" + this.sequence + ":" + first + last;
        }
        
        // Save message to JSON file
        public void saveToFile() {
            try {
                try (FileWriter writer = new FileWriter(JSON_STORAGE, true)) {
                    writer.write("{\n");
                    writer.write("  \"message_id\": \"" + this.uniqueId + "\",\n");
                    writer.write("  \"hash_value\": \"" + this.securityHash + "\",\n");
                    writer.write("  \"recipient\": \"" + this.destination + "\",\n");
                    writer.write("  \"content\": \"" + this.textContent.replace("\"", "\\\"") + "\",\n");
                    writer.write("  \"saved_at\": \"" + System.currentTimeMillis() + "\"\n");
                    writer.write("}\n");
                }
            } catch (IOException e) {
                System.err.println("Save error: " + e.getMessage());
            }
        }
        
        // Getters
        public String getId() { return uniqueId; }
        public String getHash() { return securityHash; }
        public String getRecipient() { return destination; }
        public String getContent() { return textContent; }
    }
}